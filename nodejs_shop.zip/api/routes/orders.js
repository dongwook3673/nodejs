const express = require('express');
const router = express.Router();

router.get('/', (req, res, next) => {
    res.status(200).json({
        message : 'Handling GET requests to /orders'
    });
});

router.post('/', (req, res, next) => {
    res.status(200).json({
        message : 'Handling GET requests to /orders'
    });
});

router.patch('/',(req, res, next) => {
    res.status(200).json({
        message : 'Handling PATCH requests to /orders'
    });
});

router.delete('/', (req, res, next) => {
    res.status(200).json({
        message : 'Handling DELETE requests to /orders'
    });
});

module.exports = router;